# GR Tangent Validation Matrix

{
  "failed_stages": [],
  "interpretation": "READY_FOR_C_PORT means the Python implementation is accepted as the reference oracle for a compiled-C port, not approval for a long Python production run.",
  "stage_count": 11,
  "stages": [
    {
      "passed": true,
      "path": "/home/peacelovephysics/ephemeris/output/stability/gr_tangent_validation_matrix_v1/dynamic_gr_tangent_oracle/dynamic_gr_tangent_oracle_summary.json",
      "stage": "dynamic_gr_tangent_oracle"
    },
    {
      "passed": true,
      "path": "/home/peacelovephysics/ephemeris/output/stability/gr_tangent_validation_matrix_v1/existing_1myr_smoke_audit.json",
      "stage": "existing_1myr_smoke_audit"
    },
    {
      "derived_from": "gr_tangent_summary diagnostics",
      "final_lcn_1_per_year": -9.908477548935301e-15,
      "final_megno": 2.0107497879915,
      "passed": true,
      "path": "/home/peacelovephysics/ephemeris/output/stability/gr_tangent_validation_matrix_v1/gr_100kyr_0p5d_seed12345/gr_tangent_summary_gr_100kyr_0p5d_seed12345.json",
      "runtime_seconds": 3241.8524465269875,
      "stage": "gr_100kyr_0p5d_seed12345"
    },
    {
      "derived_from": "gr_tangent_summary diagnostics",
      "final_lcn_1_per_year": -9.908687698336094e-15,
      "final_megno": 2.010749965482442,
      "passed": true,
      "path": "/home/peacelovephysics/ephemeris/output/stability/gr_tangent_validation_matrix_v1/gr_100kyr_1d_seed12345/gr_tangent_summary_gr_100kyr_1d_seed12345.json",
      "runtime_seconds": 1709.5135484312195,
      "stage": "gr_100kyr_1d_seed12345"
    },
    {
      "derived_from": "gr_tangent_summary diagnostics",
      "final_lcn_1_per_year": 2.0213823929502503e-15,
      "final_megno": 1.9818958182637114,
      "passed": true,
      "path": "/home/peacelovephysics/ephemeris/output/stability/gr_tangent_validation_matrix_v1/gr_100kyr_1d_seed67890/gr_tangent_summary_gr_100kyr_1d_seed67890.json",
      "runtime_seconds": 1648.4267402368132,
      "stage": "gr_100kyr_1d_seed67890"
    },
    {
      "passed": true,
      "path": "/home/peacelovephysics/ephemeris/output/stability/gr_tangent_validation_matrix_v1/gr_checkpoint_resume_equivalence_20kyr/gr_checkpoint_resume_equivalence_20kyr_summary.json",
      "stage": "gr_checkpoint_resume_equivalence_20kyr"
    },
    {
      "passed": true,
      "path": "/home/peacelovephysics/ephemeris/output/stability/gr_tangent_validation_matrix_v1/monitor_process_tree_audit/monitor_process_tree_audit.json",
      "stage": "monitor_process_tree_audit"
    },
    {
      "passed": true,
      "path": "/home/peacelovephysics/ephemeris/output/stability/gr_tangent_validation_matrix_v1/newtonian_zero_limit_100kyr/newtonian_zero_limit_100kyr_summary.json",
      "stage": "newtonian_zero_limit_100kyr"
    },
    {
      "passed": true,
      "path": "/home/peacelovephysics/ephemeris/output/stability/gr_tangent_validation_matrix_v1/physical_gr_trajectory_comparison_100kyr/physical_gr_trajectory_comparison_100kyr_summary.json",
      "stage": "physical_gr_trajectory_comparison_100kyr"
    },
    {
      "passed": true,
      "path": "/home/peacelovephysics/ephemeris/output/stability/gr_tangent_validation_matrix_v1/seed_comparison/gr_100kyr_1d_seed_comparison.json",
      "stage": "seed"
    },
    {
      "passed": true,
      "path": "/home/peacelovephysics/ephemeris/output/stability/gr_tangent_validation_matrix_v1/timestep_comparison/gr_100kyr_timestep_comparison.json",
      "stage": "timestep"
    }
  ],
  "status": "READY_FOR_C_PORT"
}
