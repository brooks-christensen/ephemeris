# Newtonian Zero-Limit 100 kyr

{
  "classification_custom": "regular_likely",
  "classification_native": "regular_likely",
  "duration_years": 100000,
  "max_lcn_difference": 0.0,
  "max_megno_difference": 0.0,
  "max_variation_norm_relative_difference": 0.0,
  "min_variation_direction_cosine": 0.9999999999999998,
  "outputs": {
    "csv": "/home/peacelovephysics/ephemeris/output/stability/gr_tangent_validation_matrix_v1/newtonian_zero_limit_100kyr/newtonian_zero_limit_100kyr_comparison.csv"
  },
  "passed": true,
  "stage": "newtonian_zero_limit_100kyr",
  "tolerances": {
    "direction_cosine_minimum": 0.9999999999,
    "lcn_difference": 1e-12,
    "megno_difference": 1e-10,
    "variation_norm_relative_difference": 1e-10
  }
}
