# Physical GR Trajectory Comparison 100 kyr

{
  "failures": [],
  "max_custom_vs_reboundx_scaled_phase_difference": 5.7800460588446894e-05,
  "max_element_differences": {
    "earth": {
      "max_abs_delta_a_au": 8.093437031675421e-11,
      "max_abs_delta_e": 1.8118615809081806e-10,
      "max_abs_delta_i_arcsec": 1.8051879990821362e-06,
      "max_abs_delta_mean_longitude_arcsec": 0.05368924264530506,
      "max_abs_delta_varpi_arcsec": 0.00201147790903633
    },
    "mars": {
      "max_abs_delta_a_au": 8.875300494537441e-11,
      "max_abs_delta_e": 5.514215473123585e-11,
      "max_abs_delta_i_arcsec": 6.639488958626316e-07,
      "max_abs_delta_mean_longitude_arcsec": 0.09008923992723794,
      "max_abs_delta_varpi_arcsec": 0.00017327436125924578
    },
    "mercury": {
      "max_abs_delta_a_au": 6.061040558336117e-12,
      "max_abs_delta_e": 3.248254443199983e-11,
      "max_abs_delta_i_arcsec": 1.1646235975604213e-06,
      "max_abs_delta_mean_longitude_arcsec": 0.7313429775763325,
      "max_abs_delta_varpi_arcsec": 2.9333079964999342e-05
    },
    "venus": {
      "max_abs_delta_a_au": 8.621914293627242e-11,
      "max_abs_delta_e": 1.5954112336791226e-10,
      "max_abs_delta_i_arcsec": 2.4900953299322737e-06,
      "max_abs_delta_mean_longitude_arcsec": 0.5118949747156876,
      "max_abs_delta_varpi_arcsec": 0.0021936678649581154
    }
  },
  "max_paired_gr_minus_newtonian_difference": 5.284857568277346e-05,
  "max_paired_gr_minus_newtonian_relative_difference": 6.046925216292129e-06,
  "outputs": {
    "csv": "/home/peacelovephysics/ephemeris/output/stability/gr_tangent_validation_matrix_v1/physical_gr_trajectory_comparison_100kyr/physical_gr_trajectory_comparison_100kyr.csv"
  },
  "passed": true,
  "stage": "physical_gr_trajectory_comparison_100kyr",
  "tolerances": {
    "delta_a_au": 1e-08,
    "delta_e": 1e-08,
    "delta_i_arcsec": 0.01,
    "delta_mean_longitude_arcsec": 5.0,
    "delta_varpi_arcsec": 0.01,
    "paired_gr_minus_newtonian_relative_difference": 0.0001,
    "paired_gr_minus_newtonian_scaled_phase_difference": 0.0001,
    "raw_scaled_phase_difference_warning": 0.0001
  },
  "warning": "Full-system Mercury apsidal drift is a total secular diagnostic, not the isolated 43 arcsec/century analytic test.",
  "warnings": []
}
