# Existing 1 Myr Smoke Audit

{
  "diagnostics": {
    "classification_hint": "regular_likely",
    "final_lcn_1_per_year": -5.21864680191684e-16,
    "final_megno": 2.0000416957367877,
    "max_angular_momentum_rel_drift": 5.875386746955276e-11,
    "max_energy_rel_drift": 1.351899895687132e-09,
    "mercury_perihelion_drift_arcsec_per_century": 563.8451584078925,
    "rows_written": 101,
    "runtime_seconds": 85780.04945082404
  },
  "failures": [],
  "final_time_years": 1000000.0,
  "note": "The variation_api block in the original summary is API-smoke metadata only; production N metadata is read from the archive here.",
  "passed": true,
  "production_archive_audit": {
    "final_time_years": 1000000.0,
    "n_real": 10,
    "n_total": 20,
    "n_var": 10,
    "n_var_config": 1,
    "path": "/home/peacelovephysics/ephemeris/output/stability/gr_tangent_v1/full_1myr_smoke/full_with_pluto_gr_tangent_1myr_seed12345.bin",
    "snapshot_count": 11,
    "variation_particle_count": 10
  },
  "progress_csv": "/home/peacelovephysics/ephemeris/output/stability/gr_tangent_v1/full_1myr_smoke/gr_tangent_progress_full_with_pluto_gr_tangent_1myr_seed12345.csv",
  "row_count": 101,
  "stage": "existing_1myr_smoke_audit",
  "summary_json": "/home/peacelovephysics/ephemeris/output/stability/gr_tangent_v1/full_1myr_smoke/gr_tangent_summary_full_with_pluto_gr_tangent_1myr_seed12345.json"
}
