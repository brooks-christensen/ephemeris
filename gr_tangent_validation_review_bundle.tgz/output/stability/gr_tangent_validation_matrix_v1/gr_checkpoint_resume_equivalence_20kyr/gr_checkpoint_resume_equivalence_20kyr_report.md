# GR Checkpoint Resume Equivalence 20 kyr

{
  "archive_path": "/home/peacelovephysics/ephemeris/output/stability/gr_tangent_validation_matrix_v1/gr_checkpoint_resume_equivalence_20kyr/gr_checkpoint_resume_equivalence_20kyr_checkpoint.bin",
  "callback_invocations_after_restart": 3652500,
  "classification_resumed": "regular_likely",
  "classification_uninterrupted": "regular_likely",
  "configuration_fingerprint": "f447f72b38f1a653e0d6d15290704a4486bca8c488d1751b4fef1a0009d6b3b3",
  "passed": true,
  "physical_scaled_phase_difference": 0.0,
  "resumed_lcn": -4.746134997919292e-13,
  "resumed_megno": 1.8480186884102086,
  "stage": "gr_checkpoint_resume_equivalence_20kyr",
  "tangent_direction_cosine": 1.0000000000000002,
  "tangent_scaled_phase_difference": 0.0,
  "uninterrupted_lcn": -4.746134997919292e-13,
  "uninterrupted_megno": 1.8480186884102086
}
