# Dynamic GR Tangent Oracle

{
  "epsilon_ladder": [
    1e-12,
    3e-12,
    1e-11,
    3e-11,
    1e-10,
    3e-10,
    1e-09,
    3e-09,
    1e-08,
    3e-08
  ],
  "failures": [],
  "outputs": {
    "csv": "/home/peacelovephysics/ephemeris/output/stability/gr_tangent_validation_matrix_v1/dynamic_gr_tangent_oracle/dynamic_gr_tangent_oracle.csv"
  },
  "passed": true,
  "stage": "dynamic_gr_tangent_oracle",
  "summary_by_group": {
    "0_1": {
      "best_epsilon": 3e-08,
      "max_direction_cosine": 0.9999999999998637,
      "min_relative_norm_error": 2.0037311504605167e-06
    },
    "0_10": {
      "best_epsilon": 3e-08,
      "max_direction_cosine": 0.9999999999996106,
      "min_relative_norm_error": 4.607553293994145e-06
    },
    "0_100": {
      "best_epsilon": 1e-08,
      "max_direction_cosine": 0.9999999999764548,
      "min_relative_norm_error": 1.160293737009568e-05
    },
    "1e+06_1": {
      "best_epsilon": 3e-08,
      "max_direction_cosine": 0.9999999999993076,
      "min_relative_norm_error": 1.231474562860838e-06
    },
    "1e+06_10": {
      "best_epsilon": 3e-08,
      "max_direction_cosine": 0.999999999999055,
      "min_relative_norm_error": 1.8783712556110094e-06
    },
    "1e+06_100": {
      "best_epsilon": 1e-08,
      "max_direction_cosine": 0.9999999998466065,
      "min_relative_norm_error": 2.3815075361615618e-05
    },
    "500000_1": {
      "best_epsilon": 3e-08,
      "max_direction_cosine": 0.9999999999998841,
      "min_relative_norm_error": 7.043044860791619e-07
    },
    "500000_10": {
      "best_epsilon": 3e-08,
      "max_direction_cosine": 0.9999999999997033,
      "min_relative_norm_error": 8.197133356754719e-07
    },
    "500000_100": {
      "best_epsilon": 3e-08,
      "max_direction_cosine": 0.999999999995024,
      "min_relative_norm_error": 3.159408892794432e-06
    }
  }
}
